3. Download or ensure the `Medical_insurance.csv` file is in the same directory as the script.

## Running the Application
To run the application, execute the following command in your terminal:
